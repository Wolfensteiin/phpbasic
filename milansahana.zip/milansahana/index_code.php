<?php
session_start();
require('include/db_config.php');

/*
print_r($_POST);
print_r($_FILES);
die;
*/
$back = 'index.php';

if($_SERVER['REQUEST_METHOD']=='POST')
{
	$conn1 = dbcon1();
	$name = mysqli_real_escape_string($conn1,$_POST['name']);
	$passport_no = mysqli_real_escape_string($conn1,$_POST['passport_no']);
	$date_of_birth = mysqli_real_escape_string($conn1,$_POST['date_of_birth']);
	$contact_no = mysqli_real_escape_string($conn1,$_POST['contact_no']);
	$email = mysqli_real_escape_string($conn1,$_POST['email']);
	$conn1->close();
	
	
	if(strlen($name)<1)
	{
		$_SESSION['e']='Full Name Required';
		 header('Location:'.$back);
		die();		
	}
	elseif(strlen($passport_no)!=10)
	{
		$_SESSION['e']='Valid Passport Required';
		 header('Location:'.$back);
		die();		
	}
	elseif(!ctype_alnum($passport_no))
	{
		$_SESSION['e']='Invalid Passport No';
		 header('Location:'.$back);
		die();		
	}
	elseif(strlen($date_of_birth)!=10)
	{
		$_SESSION['e']='Date of Birth Required';
		 header('Location:'.$back);
		die();		
	}
	elseif(strlen($contact_no)!=10)
	{
		$_SESSION['e']='Valid Contact No Required';
		 header('Location:'.$back);
		die();		
	}
	elseif (!filter_var($email, FILTER_VALIDATE_EMAIL))
	{
		$_SESSION['e']='Valid Email';
		 header('Location:'.$back);
		die();		
	}
	elseif(!$_FILES['user_image'])
	{
		$_SESSION['e']='Please Select a Picture';
		 header('Location:'.$back);
		die();
	}
	else
	{
		$user_image_extn =  pathinfo($_FILES['user_image']['name'],PATHINFO_EXTENSION);
		if($user_image_extn != 'jpg' AND $user_image_extn != 'jpeg')
		{
			$_SESSION['e']='Only JPEG and JPG picture allowed';
			 header('Location:'.$back);
			die();	
		}
		else
		{
			
			$target_file = 'user_image/' . uniqid().basename($_FILES["user_image"]["name"]);
			$img_upload = move_uploaded_file($_FILES["user_image"]["tmp_name"], $target_file);

			if ($img_upload)
			{
				// $file_name = basename( $_FILES["user_image"]["name"]);
				
				$conn1 = dbcon1();
				$sql1 = "INSERT INTO `user_details`(`name`, `passport_no`, `date_of_birth`, `contact_no`, `email`, `picture_name`) 
				VALUES ('".$name."', '".$passport_no."', '".$date_of_birth."', '".$contact_no."', '".$email."', '".$target_file."')";
				$res1 = mysqli_query($conn1,$sql1);
				$n1 = mysqli_insert_id($conn1);
				$conn1->close();
				
				if($res1 && $n1>0)
				{
					$_SESSION['s']='Detail Saved Successfully';
					 header('Location:view_user.php');
					die();
					
				}
				else
				{
					$_SESSION['e']='Temporary Problem in inserting data';
					 header('Location:'.$back);
					die();				
				}
			}
			else
			{
				$_SESSION['e']='Temporary Problem in uploading file';
				 header('Location:'.$back);
				die();				
			}
		}
	}
}
else
{
	
}