<?php
session_start();
?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Registration-System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <?php /*?>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <?php */?>
</head>
<body>
 
<div class="container">
  <h2 class="text-center">Registration-System <a href="view_user.php" class="pull-right">Grid View</a></h2>
	 <form action="index_code.php" class="form-horizontal" enctype="multipart/form-data" method="post" name="">
		  <div class="form-group">
		 	  <?php
			  if(isset($_SESSION['s']))
			  {
			  ?>
		  	<div class="alert alert-success">
			  <strong><?php echo $_SESSION['s']; unset($_SESSION['s']); ?></strong>
			</div>
			<?php
			  }
			  if(isset($_SESSION['e']))
			  {
			?>

			<div class="alert alert-danger">
			  <strong><?php echo $_SESSION['e']; unset($_SESSION['e']); ?></strong>
			</div>
		  	<?php
			  }
			 ?>
		  </div>
		  <div class="form-group">
			<label class="control-label col-sm-4" for="name">Name:</label>
				<div class="col-sm-6">
					<input type="text" pattern="[a-zA-Z\s]+" title="Full Name(Character Only)" name="name" class="form-control" id="name" placeholder="Full Name" required>
			  	</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-sm-4" for="passport_no">Passport No:</label>
				<div class="col-sm-6">
					<input type="text" pattern="[a-zA-Z0-9]+" maxlength="10" title="Valid Passport Number Only" name="passport_no" class="form-control" id="passport_no" placeholder="Passport No" required>
			  	</div>
		  </div>
		  
		  <div class="form-group">
			<label class="control-label col-sm-4" for="date_of_birth">Date of Birth:</label>
				<div class="col-sm-6">
					<input type="date" name="date_of_birth" class="form-control" id="date_of_birth" placeholder="Passport No" required>
			  	</div>
		  </div>
		  
		  <div class="form-group">
			<label class="control-label col-sm-4" for="contact_no">Contact No:</label>
				<div class="col-sm-6">
					<input type="tel" pattern= "[6-9]{1}[0-9]{9}" maxlength="10" title="10 digit Mobile Number" name="contact_no" class="form-control" id="contact_no" placeholder="Contact No" required>
			  	</div>
		  </div>
		  
		  <div class="form-group">
		   <label class="control-label col-sm-4" for="email">Email:</label>
				<div class="col-sm-6">
					<input type="email" name="email" class="form-control" id="email" required>
			  	</div>
		  </div>
		  <div class="form-group">
		   <label class="control-label col-sm-4" for="user_image">Upload Picture:</label>
				<div class="col-sm-6">
					<input type="file" name="user_image" accept=".jpg,.jpeg" id="user_image" required>
			  	</div>
		  </div>

			<div class="form-group">        
			  <div class="col-sm-offset-4 col-sm-6">
				<button type="submit" class="btn btn-success"> Submit </button>
				&nbsp;&nbsp;
				<button type="reset" class="btn btn-warning"> Cancel </button>
			  </div>
			</div>
	</form> 


</div>
</body>
</html>
