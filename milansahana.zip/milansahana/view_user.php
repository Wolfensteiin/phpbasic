<?php
session_start();
require('include/db_config.php');
?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Registration-System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <?php /*?>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <?php */?>
</head>
<body>
 
<div class="container">
	  <?php
	  if(isset($_SESSION['s']))
	  {
	  ?>
	<div class="alert alert-success">
	  <strong><?php echo $_SESSION['s']; unset($_SESSION['s']); ?></strong>
	</div>
	<?php
	  }
	  if(isset($_SESSION['e']))
	  {
	?>

	<div class="alert alert-danger">
	  <strong><?php echo $_SESSION['e']; unset($_SESSION['e']); ?></strong>
	</div>
	<?php
	  }
	 ?>
  <h2 class="text-center">Grid View <a href="index.php" class="pull-right">Add New</a></h2>
  <?php
	$sql1 = "SELECT `name`, `passport_no`, `date_of_birth`, `contact_no`, `email`, `picture_name` FROM `user_details` ORDER BY created_on DESC ";
	$conn1 = dbcon1();
	$res1 = mysqli_query($conn1,$sql1);
	$n1 = mysqli_num_rows($res1);
	$conn1->close();
	if($n1)
	{
	?>
  <table class="table table-condensed">
    <thead>
      <tr>
        <th>Name</th>
        <th>Passport No</th>
        <th>Date of Birth</th>
        <th>Contact No</th>
        <th>Email</th>
        <th>Picture</th>
      </tr>
    </thead>
    <tbody>
		<?php
		while($arr1 = mysqli_fetch_assoc($res1))
		{
		?>
      <tr>
        <td><?php echo $arr1['name']; ?></td>
        <td><?php echo $arr1['passport_no']; ?></td>
        <td><?php echo $arr1['date_of_birth']; ?></td>
        <td><?php echo $arr1['contact_no']; ?></td>
        <td><?php echo $arr1['email']; ?></td>
        <td>
         <img src="<?php echo $arr1['picture_name']; ?>" class="img-responsive" style="max-height: 70px;"> 
         </td>
      </tr>
      <?php
		}
		?>
    </tbody>
  </table> 
<?php
	}
	?>

</div>
</body>
</html>
